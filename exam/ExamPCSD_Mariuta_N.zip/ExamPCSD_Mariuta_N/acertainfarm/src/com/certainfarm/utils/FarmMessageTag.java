package com.certainfarm.utils;
	
	public enum FarmMessageTag {
		NEWMEASUREMENTS, UPDATE, QUERY;
	}

